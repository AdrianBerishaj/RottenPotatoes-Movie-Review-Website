const LocalStrategy = require('passport-local').Strategy;
const mysql = require('mysql');
const bcrypt = require('bcryptjs');

//create connection to db
const db = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: 'genomall',
    database: 'rottenpotatoes'
});

// connect to db
db.connect((err) => {
    if(err) throw err;
    console.log('MySql connected to passport.js');
});

module.exports = function(passport) {
    passport.use(
        new LocalStrategy({usernameField: 'email'}, (email, password, done) => {
            //check if email exists
            let checkEmailQuery = 
            `SELECT COUNT(*) AS email
            FROM user
            WHERE user_email LIKE '${email}'`;

            db.query(checkEmailQuery, (err, result) => {
                if(err) throw err;
                console.log('login: email checked in database');
                if(result[0].email == 0){
                    console.log('email has not yet been registered');
                    return done(null, false, { message: 'Email is not registered'});
                }
                // if email exists, get user's info
                else{
                    let getUserQuery = 
                    `SELECT 
                    user_nickname AS userName,
                    user_id AS id,
                    user_email AS email,
                    user_password AS password
                    FROM user
                    WHERE user_email LIKE '${email}'`;

                    db.query(getUserQuery, (err, result) => {
                        if(err) throw err;
                        console.log('login: user found');

                        //match password
                        bcrypt.compare(password, result[0].password, (err, isMatch) => {
                            if(err) throw err;
                            //if match return user (result)
                            if(isMatch) {
                                console.log('password was correct');   
                                console.log('User logged in');
                                console.log(result[0]);
                                return done(null, result[0]); //user has passed login
                            } else {
                                console.log('password was incorrect');
                                return done(null, false, { message: 'Password incorrect'});
                            }
                        }); //end bcrypt compare

                    }); //end getUserQuery

                } //end else

            }); //end checkEmail query

        }) //end local strategy

    ); //end passport.use

    passport.serializeUser((user, done) => {
        done(null, user.id);
    });

    passport.deserializeUser((id, done) => {
        let getUserQuery = 
            `SELECT *
            FROM user
            WHERE user_id LIKE '${id}'`;
        db.query(getUserQuery, (err, result) => {
            if(err) throw err;
            done(err, result);
        });
    });
};