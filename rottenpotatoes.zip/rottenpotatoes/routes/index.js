const express = require('express');
const mysql = require('mysql');
const router = express.Router();
const { ensureAuthenticated } = require('../config/auth');

//create connection to db
const db = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: 'genomall', //change to env variable later on
    database: 'rottenpotatoes'
});

// connect to db
db.connect((err) => {
    if(err) throw err;
    console.log('MySql connected to index.js');
});

//queries specifically for displaying and organizing the search categories to choose from in the dropdown fields
let movieQuery = 'SELECT movie_id, movie_name, movie_year, movie_mpaa_rating, movie_director, movie_budget FROM movie';
let yearQuery = 'SELECT DISTINCT movie_year FROM movie ORDER BY movie_year DESC'
let genreQuery = 'SELECT DISTINCT movie_genre FROM movie_genre ORDER BY movie_genre DESC';
let actorQuery = 'SELECT actor_id, actor_fname, actor_lname FROM actor';
let dbMovie;
let dbYear;
let dbGenre;
let dbActor;
db.query(movieQuery, (err, result) => {
    if(err) throw err;
    dbMovie = result;
});

db.query(genreQuery, (err, result) => {
    if(err) throw err;
    dbGenre = result;
});

db.query(yearQuery, (err, result) => {
    if(err) throw err;
    dbYear = result;
});

db.query(actorQuery, (err, result) => {
    if(err) throw err;
    dbActor = result;
});

//welcome page
router.get('/', (req, res) => res.render('welcome'));

//home page
router.get('/search', ensureAuthenticated, (req, res) => {
    res.render('search', {
        user: req.user[0],
        searchResults: null,
        movie: dbMovie,
        genre: dbGenre,
        actor: dbActor,
        year: dbYear
    })
}); //pass user into home page, useable with ejs

router.post('/search', ensureAuthenticated, (req, res) => {
    //does generic search, modified by appending where clauses based on the dropdown selections
    let searchQuery =
    `SELECT *
    FROM movie
    LEFT OUTER JOIN movie_genre ON movie.movie_id = movie_genre.movie_id
    LEFT OUTER JOIN movie_cast ON movie.movie_id = movie_cast.movie_id
    LEFT OUTER JOIN actor ON movie_cast.actor_id = actor.actor_id
    WHERE 1 = 1`;

    let {year, genre, actor} = req.body;

  
    //WHERE clause builder
    if(year){
        searchQuery += ` AND movie.movie_year = ${year}`;
    }

    if(genre){
        searchQuery += ` AND movie_genre.movie_genre = '${genre}'`;
    }

    if(actor){
        searchQuery += ` AND actor.actor_id = ${actor}`;
    }


    console.log(searchQuery);

    db.query(searchQuery, (err, result) => {
        if(err) throw err;
        searchResults = result;

        console.log(searchResults);

        res.render('search', {
            searchResults: searchResults,
            user: req.user[0],
            movie: dbMovie,
            genre: dbGenre,
            actor: dbActor,
            year: dbYear
        });

    });
});



module.exports = router;