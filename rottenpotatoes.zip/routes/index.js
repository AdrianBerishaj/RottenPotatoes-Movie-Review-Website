const express = require('express');
const mysql = require('mysql');
const router = express.Router();
const { ensureAuthenticated } = require('../config/auth');

//create connection to db
const db = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: 'genomall', //change to env variable later on
    database: 'rottenpotatoes'
});

// connect to db
db.connect((err) => {
    if(err) throw err;
    console.log('MySql connected to index.js');
});

let movieQuery = 'SELECT movie_id, movie_name, movie_year, movie_mpaa_rating, movie_director, movie_budget FROM movie';
let genreQuery = 'SELECT movie_id, movie_genre FROM movie_genre';
let actorQuery = 'SELECT actor_id, actor_fname, actor_lname FROM actor';
let dbMovie;
let dbGenre;
let dbActor;
db.query(movieQuery, (err, result) => {
    if(err) throw err;
    dbMovie = result;
});

db.query(genreQuery, (err, result) => {
    if(err) throw err;
    dbGenre = result;
});

db.query(actorQuery, (err, result) => {
    if(err) throw err;
    dbActor = result;
});

//welcome page
router.get('/', (req, res) => res.render('welcome'));

//home page
router.get('/search', ensureAuthenticated, (req, res) => {
    res.render('search', {
        user: req.user[0],
        searchResults: null,
        movie: dbMovie,
        movie_genre: dbGenre,
        actor: dbActor
    })
}); //pass user into home page, useable with ejs

router.post('/search', ensureAuthenticated, (req, res) => {

    let searchQuery = 
    `SELECT *
    FROM movie
    WHERE 1 = 1`;

    let {year, genre, actor} = req.body;

  
    //WHERE clause builder
    if(year){
        searchQuery += ` AND movie_year = ${year}`;
    }

    console.log(searchQuery);

    db.query(searchQuery, (err, result) => {
        if(err) throw err;
        searchResults = result;

        console.log(searchResults);
        console.log(searchResults[0].MOVIE_NAME);

        res.render('search', {
            searchResults: searchResults,
            user: req.user[0],
            movie: dbMovie,
            movie_genre: dbGenre,
            actor: dbActor    
        });

    });
});



module.exports = router;