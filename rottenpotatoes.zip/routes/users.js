const express = require('express');
const mysql = require('mysql');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
const { ensureAuthenticated } = require('../config/auth');

//create connection to db
const db = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: 'genomall', //change to env variable later on
    database: 'rottenpotatoes'
});

// connect to db
db.connect((err) => {
    if(err) throw err;
    console.log('MySql connected to users.js');
});

// Login page
router.get('/login', (req, res) => res.render('Login'));

// Register page
router.get('/register', (req, res) => res.render('Register'));

// Register user into database
router.post('/register', (req, res) => {
    const { uname, email, password, password2 } = req.body;
    console.log(req.body);
    let errors = [];

    //check required fields
    if(!uname || !email || !password || !password2) {
        errors.push({msg: 'please fill in all fields'});
    }
    //Check if passwords match
    if(password !== password2) {
        errors.push({ msg: 'Passwords do not match'});
    }
    //Password requirements
    if(password.length < 6) {
        errors.push({ msg: 'Password should be at least six characters'});
    }
    //check if email is being used
    let checkEmailQuery = 
        `SELECT COUNT(*) AS email
        FROM user
        WHERE user_email LIKE '${email}'`;

        db.query(checkEmailQuery, (err, result) => {
            if(err) throw err;
            console.log('register: email checked in database');
            if(result[0].email > 0){
                errors.push({ msg: 'Email is already registered'});
                console.log('email is already in use');
            }

            //check for any input errors
            if(errors.length > 0) {
                console.log('user register failed');
                res.render('register', {
                    errors,
                    uname,
                    email,
                    password,
                    password2
                });
                console.log(errors);
            }
            //if no errors, register user
            else {
        
                //Hash password
                bcrypt.genSalt(10, (err, salt) => 
                    bcrypt.hash(password, salt, (err, hash) => {
                        if(err) throw err;
                        let hashedPassword = hash;
        
                        let addUserQuery = 
                        `INSERT INTO user 
                        (user_nickname, user_email, user_password) 
                        VALUES ('${uname}', '${email}', '${hashedPassword}')`;  
        
                        //add user to database
                        db.query(addUserQuery, (err, result) => {
                            if(err) throw err;
                            console.log('user successfully entered into database');
                            //session storage for redirect notification
                            req.flash('pass_msg', 'Registration sucessful.');
                            res.redirect('/users/login');
        
                        });
                    })
                );
            }   
        });

});

// login
router.post('/login', (req, res, next) => {
    passport.authenticate('local', {
        successRedirect: '/search',
        failureRedirect: '/users/login',
        failureFlash: true
    }) (req, res, next);
});

// Logout route
router.get('/logout', (req, res) => {
    req.logout();
    req.logout();

    console.log(`User logged out`);
    req.flash('pass_msg', 'Sucessfully logged out.');
    res.redirect('/users/login');
});

// Account settings route
router.get('/account', ensureAuthenticated, (req, res) => {
    let updatedInput = { user_nickname: ''};
        
    console.log(req.user[0]);

    res.render('account', {
        user: req.user[0],
        updatedUser: updatedInput,
    });
});

router.post('/account', (req, res) => {
    const { inputUname } = req.body;
    let updatedInput = { user_nickname: inputUname};
    let passes = [];

        if(inputUname !=  ''){
            let updateUnameQuery = 
            `UPDATE user
            SET user_nickname = "${inputUname}"
            WHERE user_id = ${req.user[0].user_id}`

            passes.push({ msg: 'Username updated.'});
            
            db.query(updateUnameQuery, (err, result) => {
                if(err) throw err;
                console.log(`user nickname updated to "${inputUname}"`);
            });
        }

    console.log(updatedInput);
    res.render('account', {
        user: req.user[0],
        updatedUser: updatedInput, 
        passes
    });

});

module.exports = router;